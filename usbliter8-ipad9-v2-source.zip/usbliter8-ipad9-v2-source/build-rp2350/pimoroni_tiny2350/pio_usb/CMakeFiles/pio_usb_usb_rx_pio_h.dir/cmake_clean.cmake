file(REMOVE_RECURSE
  "CMakeFiles/pio_usb_usb_rx_pio_h"
  "usb_rx.pio.h"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/pio_usb_usb_rx_pio_h.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
