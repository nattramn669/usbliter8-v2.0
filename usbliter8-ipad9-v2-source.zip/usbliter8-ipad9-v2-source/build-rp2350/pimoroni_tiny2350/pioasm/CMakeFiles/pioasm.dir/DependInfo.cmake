
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/Users/natan/Documents/Codex/2026-07-09/es/work/usbliter8-ipad9-diagnostic/.toolchains/pico-sdk/tools/pioasm/ada_output.cpp" "CMakeFiles/pioasm.dir/ada_output.cpp.o" "gcc" "CMakeFiles/pioasm.dir/ada_output.cpp.o.d"
  "/Users/natan/Documents/Codex/2026-07-09/es/work/usbliter8-ipad9-diagnostic/.toolchains/pico-sdk/tools/pioasm/c_sdk_output.cpp" "CMakeFiles/pioasm.dir/c_sdk_output.cpp.o" "gcc" "CMakeFiles/pioasm.dir/c_sdk_output.cpp.o.d"
  "/Users/natan/Documents/Codex/2026-07-09/es/work/usbliter8-ipad9-diagnostic/.toolchains/pico-sdk/tools/pioasm/gen/lexer.cpp" "CMakeFiles/pioasm.dir/gen/lexer.cpp.o" "gcc" "CMakeFiles/pioasm.dir/gen/lexer.cpp.o.d"
  "/Users/natan/Documents/Codex/2026-07-09/es/work/usbliter8-ipad9-diagnostic/.toolchains/pico-sdk/tools/pioasm/gen/parser.cpp" "CMakeFiles/pioasm.dir/gen/parser.cpp.o" "gcc" "CMakeFiles/pioasm.dir/gen/parser.cpp.o.d"
  "/Users/natan/Documents/Codex/2026-07-09/es/work/usbliter8-ipad9-diagnostic/.toolchains/pico-sdk/tools/pioasm/go_output.cpp" "CMakeFiles/pioasm.dir/go_output.cpp.o" "gcc" "CMakeFiles/pioasm.dir/go_output.cpp.o.d"
  "/Users/natan/Documents/Codex/2026-07-09/es/work/usbliter8-ipad9-diagnostic/.toolchains/pico-sdk/tools/pioasm/hex_output.cpp" "CMakeFiles/pioasm.dir/hex_output.cpp.o" "gcc" "CMakeFiles/pioasm.dir/hex_output.cpp.o.d"
  "/Users/natan/Documents/Codex/2026-07-09/es/work/usbliter8-ipad9-diagnostic/.toolchains/pico-sdk/tools/pioasm/json_output.cpp" "CMakeFiles/pioasm.dir/json_output.cpp.o" "gcc" "CMakeFiles/pioasm.dir/json_output.cpp.o.d"
  "/Users/natan/Documents/Codex/2026-07-09/es/work/usbliter8-ipad9-diagnostic/.toolchains/pico-sdk/tools/pioasm/main.cpp" "CMakeFiles/pioasm.dir/main.cpp.o" "gcc" "CMakeFiles/pioasm.dir/main.cpp.o.d"
  "/Users/natan/Documents/Codex/2026-07-09/es/work/usbliter8-ipad9-diagnostic/.toolchains/pico-sdk/tools/pioasm/pio_assembler.cpp" "CMakeFiles/pioasm.dir/pio_assembler.cpp.o" "gcc" "CMakeFiles/pioasm.dir/pio_assembler.cpp.o.d"
  "/Users/natan/Documents/Codex/2026-07-09/es/work/usbliter8-ipad9-diagnostic/.toolchains/pico-sdk/tools/pioasm/pio_disassembler.cpp" "CMakeFiles/pioasm.dir/pio_disassembler.cpp.o" "gcc" "CMakeFiles/pioasm.dir/pio_disassembler.cpp.o.d"
  "/Users/natan/Documents/Codex/2026-07-09/es/work/usbliter8-ipad9-diagnostic/.toolchains/pico-sdk/tools/pioasm/python_output.cpp" "CMakeFiles/pioasm.dir/python_output.cpp.o" "gcc" "CMakeFiles/pioasm.dir/python_output.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
